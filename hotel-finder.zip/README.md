# 🏨 HotelXplore

Kisi bhi shahar ke hotels, tourist places aur restaurants ek click mein dhundho.

## ✅ Features
- 🔍 City name se search karo
- 📍 Apni current location se dhundho
- 🏨 Hotels | 🗺️ Tourist Places | 🍽️ Restaurants
- 🗺️ Live Map with markers (Leaflet.js)
- 📏 Distance bhi dikhata hai
- 💯 FREE – No API key needed!

## 🚀 GitHub Pages par Deploy kaise karein?

1. GitHub par nayi repository banao (e.g. `hotel-finder`)
2. Ye teeno files upload karo:
   - `index.html`
   - `style.css`
   - `app.js`
3. Repository Settings → Pages → Source: `main` branch → Save
4. Aapki website live ho jayegi:
   `https://YOUR_USERNAME.github.io/hotel-finder`

## 📁 Files
| File | Kaam |
|------|------|
| `index.html` | Main webpage structure |
| `style.css` | Design & styling |
| `app.js` | Search, API calls, Map logic |

## 🛠️ APIs Used (All FREE)
- **Nominatim** (OpenStreetMap) – City name → coordinates
- **Overpass API** – Nearby places data
- **Leaflet.js** – Interactive map

## ✏️ Customize karna ho to
- `app.js` mein `radius = 5000` → zyada door ke results ke liye badhaao (meters mein)
- `style.css` mein `--accent` color badlo apni pasand ka
